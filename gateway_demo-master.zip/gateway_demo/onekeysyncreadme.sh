#!/bin/sh
cp -rf README.md  /Users/niuyufu/go/src/github.com/e421083458/go_gateway
cp -rf README.md /Users/niuyufu/VueProjects/go_gateway_view
cp -rf README.md  /Users/niuyufu/imooc/go_gateway
cp -rf README.md  /Users/niuyufu/imooc/go_gateway_view
cp -rf README.md  /Users/niuyufu/imooc/gateway_demo
